window.addEventListener('message', (event) => {
  if (event.data && event.data.from == 'extension') {
    switch (event.data.message.command) {
      case 'import-bookmarks':
      case 'import-top-sites':
      case 'import-bookmark-history':
      case 'import-browser-tabs':
        let body = {
          command: event.data.message.command,
          data: event.data.message.data,
          param: event.data.message.param,
          param2: event.data.message.param2,
        };

        let xhr = new XMLHttpRequest();
        xhr.open('POST', 'http://localhost:8765/');
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(body));
        break;
      default:
        console.log(`event not handled ${event}`);
        break;
    }
  }
});

function sendToExtension(command, param, param2, param3) {
  window.parent.postMessage(
    {
      from: 'flutter',
      command: command,
      param: param,
      param2: param2,
      param3: param3,
    },
    '*',
  );
}
